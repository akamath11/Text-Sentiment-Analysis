import scipy.optimize
from sklearn.metrics import accuracy_score
from sklearn.cross_validation import KFold
import numpy as np
import math


def train(X,Y,w,dict_intersection):
    max_epochs=10
    numFolds = 5
    minibatchsize=100
    lamda=0.001
    step=0.00001
    Epoch_accuracy=0
    Epoch_loss=0
    
    for epoch in range(max_epochs):
        #print(epoch)
        Total_accuracy=0
        Total_loss=0
        count=0

        for i in range(0,Y.shape[0]-minibatchsize,minibatchsize):
            total=0
            Loss=0
            Xn=X[i:i + minibatchsize]
            Yn=Y[i:i + minibatchsize]

            kf = KFold(len(range(Yn.shape[0])), numFolds, shuffle=True)
            for train_indices, test_indices in kf:
                
                X_train = Xn[train_indices]
                Y_train = Yn[train_indices]
                
                grad=gradient(X_train, Y_train,w,lamda)

                w=w+step*grad
 
                X_test  = Xn[test_indices]
                Y_test  = Yn[test_indices]
                
                Y_true=Y_test.nonzero()[1]
 
                predictions,loss = predict(X_test,Y_test,w,lamda,dict_intersection)
                
                predicted_class=np.argmax(predictions,axis=1)   #hard_prediction

                if(len(Y_true)!=0):
                    total += float(np.sum(np.array(Y_true)==np.array(predicted_class)))/len(Y_true)
                Loss=Loss+loss
            accuracy = float(total) / numFolds
            Loss = float(Loss)/numFolds
            Total_accuracy += accuracy
            Total_loss+=Loss
            count=count+1
        Total_accuracy=float(Total_accuracy)/count
        Total_loss=float(Total_loss)/count
        Epoch_accuracy+=Total_accuracy
        Epoch_loss+=Total_loss

        
    Epoch_accuracy=float(Epoch_accuracy)/(epoch+1)
    Epoch_loss=float(Epoch_loss)/(epoch+1)
    
    print(Epoch_accuracy)
    print(Epoch_loss)
        
    return w
        
def gradient(X,Y,w,lamda):
    numerator=np.array(np.exp(X*w.T))
    den=numerator.sum(axis=1)
    denominator=np.array([den]*5).T     
    denominator[denominator==0]=1

    grad=(Y-numerator/denominator).T*X-lamda*w

    return grad
    
def predict(X,Y,w,lamda,dict_intersection):
    numerator=np.array(np.exp(X*w.T))
    den=numerator.sum(axis=1)
    denominator=np.array([den]*5).T
    denominator[denominator==0]=1
    prediction=numerator/denominator
    loss=np.sum(np.multiply(Y.todense(),prediction))
    #remove this line
    loss=loss-np.array(np.matrix(dict_intersection)*w.T).sum()
    return prediction,loss
    
def predict_dev(X,w,lamda,fout):
    numerator=np.array(np.exp(X*w.T))
    den=numerator.sum(axis=1)
    denominator=np.array([den]*5).T
    denominator[denominator==0]=1
    prediction=numerator/denominator
    hard_prediction=np.argmax(prediction,axis=1)+1
    soft_prediction=np.matrix([1,2,3,4,5])*(prediction.T)
    for i in range(len(hard_prediction)):
        fout.write(str(hard_prediction[i])+' '+str( np.array(soft_prediction).flatten()[i])+'\n') 
        
    return (hard_prediction,soft_prediction)

    

            
            
            
 
    
        