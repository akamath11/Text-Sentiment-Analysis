Logistic Regresison:
1) Run Main_Log_reg - This performs all the steps upto training the logistic regression classifier.The weights are saved.
2) To run for development set, Use Dev_test_log_reg after training. This calls the predict_dev function in Log_Reg and uses the saved weights.

SVM:
1) Main_SVM uses Liblinear module, calls the Dev_test_SVM

Feature Engineering:
1) Similarly for the Feature Engineering section codes - Main_new_feature and Dev_test_SVM_new_feature