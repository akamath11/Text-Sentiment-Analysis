import string
import numpy as np
import collections
from scipy import sparse
import pandas as pd

from liblinearutil import *

json_data=open('yelp_reviews_train.json').read()

data=json_data.split('\n')


stopwords=open('stopword.list').read()
stopwords=set(stopwords)

start = '"text":'
end = '"type"'

start1='"stars":'
end1=','

dictionary={}
dictionary1={}
dictionary2={}
dictionary3={}
dictionary4={}
dictionary5={}
dictionary_doc={}
reviews=[]
l=[]
w=np.zeros([5,2000])


for i in range(len(data)-1):
    print(i)
    s = data[i]
    text=(s.split(start))[1].split(end)[0].lower()
    stars=int((s.split(start1))[1].split(end1)[0])
    text=text.translate(None, string.punctuation)
    text=text.translate(None, '0123456789')
    text=text.split(' ')
    text1=list(set(text)) 
    
    for word in text:
            if word not in stopwords:
                if stars==1:
                    if word not in dictionary1:
                        dictionary1[word]=1
                    else:
                        dictionary1[word]=dictionary1[word]+1
                
                if stars==2:
                    if word not in dictionary2:
                        dictionary2[word]=1
                    else:
                        dictionary2[word]=dictionary2[word]+1
                    
                if stars==3:
                    if word not in dictionary3:
                        dictionary3[word]=1
                    else:
                        dictionary3[word]=dictionary3[word]+1
                
                if stars==4:
                    if word not in dictionary4:
                        dictionary4[word]=1
                    else:
                        dictionary4[word]=dictionary4[word]+1
                
                if stars==5:
                    if word not in dictionary5:
                        dictionary5[word]=1
                    else:
                        dictionary5[word]=dictionary5[word]+1
                        

                    
                
min_value1=np.sort(dictionary1.values())[::-1][1500]  #Term Frequency
min_value2=np.sort(dictionary2.values())[::-1][1500]
min_value3=np.sort(dictionary3.values())[::-1][1500]
min_value4=np.sort(dictionary4.values())[::-1][1500]
min_value5=np.sort(dictionary5.values())[::-1][1500]


#top 1000 dictionaries
dict_1=[]
dict_2=[]
dict_3=[]
dict_4=[]
dict_5=[]


for key in dictionary1.keys():
    if dictionary1[key]>=min_value1:
        dict_1.insert(0,key)
        
for key in dictionary2.keys():
    if dictionary2[key]>=min_value2:
        dict_2.insert(0,key)
        
for key in dictionary3.keys():
    if dictionary3[key]>=min_value3:
        dict_3.insert(0,key)
        
for key in dictionary4.keys():
    if dictionary4[key]>=min_value4:
        dict_4.insert(0,key)
        
for key in dictionary5.keys():
    if dictionary5[key]>=min_value5:
        dict_5.insert(0,key)
        
dict_1=set(dict_1)
dict_2=set(dict_2)
dict_3=set(dict_3)
dict_4=set(dict_4)
dict_5=set(dict_5)
        

#dict_intersection= dict_1 & dict_2 & dict_3 & dict_4 & dict_5
dict_union= dict_1|dict_2|dict_3|dict_4|dict_5

dict_2000=list(dict_union)[:-2]
print(len(dict_2000))
  
l_stars=[]

                               
for i in range(len(data)-1):
    print(i)
    s = data[i]
    stars=int((s.split(start1))[1].split(end1)[0])
    l_stars.append(stars)
    text=(s.split(start))[1].split(end)[0].lower()
    text=text.translate(None, string.punctuation)
    text=text.translate(None, '0123456789')
    text=text.split(' ')
    

    review_dictionary=collections.OrderedDict()
    for word in text:
        if word in dict_2000: 
            if word not in review_dictionary:
                review_dictionary[word]=1
                word_index=dict_2000.index(word)
                l.append([i,word_index,1])
            else:
                review_dictionary[word]=review_dictionary[word]+1
                index=review_dictionary.keys().index(word)
                l[-(len(review_dictionary)-index)][2]+=1
#   


df=pd.DataFrame(l)
X=sparse.csr_matrix((df[2],(df[0],df[1])),shape=(i+1,2000))  
Y= np.array(l_stars)
prob=problem(Y,X)
param = parameter('-s 2')
m=train(prob,param)

import Dev_test_SVM_new_feature
Dev_test_SVM_new_feature.test(m,dict_2000)
        

#import pickle
#pickle_path = 'Training_weights.pickle'
#pickle_file = open(pickle_path, 'wb')
#pickle.dump(w, pickle_file)
#pickle_file.close() 



                    



  
    
    
      

    
    
        


    
            
        

