#y ndarray int or double - l labelse
#x l*n scipy spmatrix (n: number of features)

import string
import numpy as np
import collections
from scipy import sparse
import pandas as pd


from liblinearutil import *

json_data=open('yelp_reviews_train.json').read()

data=json_data.split('\n')

stopwords=open('stopword.list').read()
stopwords=set(stopwords)

start = '"text":'
end = '"type"'

start1='"stars":'
end1=','

dictionary={}
dictionary_doc={}
reviews=[]
l=[]
w=np.zeros([5,2000])

for i in range(len(data)-1):
    print(i)
    s = data[i]
    text=(s.split(start))[1].split(end)[0].lower()
    text=text.translate(None, string.punctuation)
    text=text.translate(None, '0123456789')
    text=text.split(' ')
    text1=list(set(text))    
    
#    for word in text:
#            if word not in stopwords:
#                if word not in dictionary:
#                    dictionary[word]=1
#                else:
#                    dictionary[word]=dictionary[word]+1
                    
    for word in text1:
            if word not in stopwords:
                if word not in dictionary_doc:
                    dictionary_doc[word]=1
                else:
                    dictionary_doc[word]=dictionary_doc[word]+1
    
dict_2000=[]
# Dictionary top2000
#min_value=np.sort(dictionary.values())[::-1][1999]  #Term Frequency
min_value=np.sort(dictionary_doc.values())[::-1][1999]  #Document Frequency

#for key in dictionary.keys():
#    if dictionary[key]>=min_value:
#        dict_2000.insert(0,key)
#        
for key in dictionary_doc.keys():
    if dictionary_doc[key]>=min_value:
        dict_2000.insert(0,key)        
 
del dictionary       
l_stars=[]
j=0

           
json_data=open('yelp_reviews_train.json').read()

data=json_data.split('\n')
            
for i in range(len(data)-1):
    print(i)
    s = data[i]
    stars=int((s.split(start1))[1].split(end1)[0])
    l_stars.append(stars)
    text=(s.split(start))[1].split(end)[0].lower()
    text=text.translate(None, string.punctuation)
    text=text.translate(None, '0123456789')
    text=text.split(' ')
    

    review_dictionary=collections.OrderedDict()
    for word in text:
        if word in dict_2000: 
            if word not in review_dictionary:
                review_dictionary[word]=1
                word_index=dict_2000.index(word)
                l.append([i,word_index,1])
            else:
                review_dictionary[word]=review_dictionary[word]+1
                index=review_dictionary.keys().index(word)
                l[-(len(review_dictionary)-index)][2]+=1
#   


df=pd.DataFrame(l)
X=sparse.csr_matrix((df[2],(df[0],df[1])),shape=(i+1,2000))  
Y= np.array(l_stars)

prob=problem(Y,X)
param = parameter('-s 2')
m=train(prob,param)

import Dev_test_SVM
Dev_test_SVM.test(m)
        

import pickle
pickle_path = 'Training_weights.pickle'
pickle_file = open(pickle_path, 'wb')
pickle.dump(w, pickle_file)
pickle_file.close() 



                    



  
    
    
      

    
    
        


    
            
        

